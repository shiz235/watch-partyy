/* Replace these two values with your Supabase Project URL and browser-safe publishable key. */
const SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
const SUPABASE_KEY = 'PASTE_YOUR_PUBLISHABLE_KEY_HERE';

let supabaseClient=null, channel=null, roomCode='', userName='', isHost=false, currentRoomUrl='';
const $=id=>document.getElementById(id);
function setStatus(x){$('status').textContent=x}
function msg(x){$('joinMessage').textContent=x}
function makeCode(){return Math.random().toString(36).slice(2,8).toUpperCase()}
function validConfig(){return SUPABASE_URL.startsWith('http')&&!SUPABASE_KEY.startsWith('PASTE_')}
function createRoom(){roomCode=makeCode();$('roomInput').value=roomCode;joinRoom(true)}
async function joinRoom(autoHost=false){
  userName=$('nameInput').value.trim()||'Guest';roomCode=($('roomInput').value.trim()||'').toUpperCase();
  if(!roomCode){msg('Enter a room code or create a room.');return}
  if(!validConfig()){msg('Add your Supabase URL and publishable key in watch-party.js first.');return}
  isHost=autoHost;
  supabaseClient=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
  $('joinScreen').classList.add('hidden');$('roomScreen').classList.remove('hidden');$('roomCodeDisplay').textContent=roomCode;setStatus('Connecting…');
  channel=supabaseClient.channel('watch-party-'+roomCode,{config:{broadcast:{ack:true},presence:{key:userName+'-'+Math.random().toString(36).slice(2)}}});
  channel.on('broadcast',{event:'command'},({payload})=>handleCommand(payload)).on('broadcast',{event:'source'},({payload})=>handleSource(payload)).on('broadcast',{event:'request-state'},()=>{if(isHost)sendCurrentState()}).on('presence',{event:'sync'},updatePeople);
  await channel.subscribe(async status=>{if(status==='SUBSCRIBED'){setStatus('Connected');await channel.track({name:userName});if(!isHost)channel.send({type:'broadcast',event:'request-state',payload:{}})}});
}
function updatePeople(){if(!channel)return;const state=channel.presenceState();$('peopleCount').textContent=Object.values(state).reduce((n,a)=>n+a.length,0)}
async function broadcast(event,payload){if(channel)await channel.send({type:'broadcast',event,payload})}
async function openUrl(){const url=$('urlInput').value.trim();if(!url)return;try{setupPlayer(url);currentRoomUrl=url;await broadcast('source',{url});setStatus(playerMode==='iframe'?'Loaded (site controls may not sync)':'Player ready');}catch(e){setStatus(e.message)}}
function handleSource(p){if(!p?.url)return;$('urlInput').value=p.url;try{setupPlayer(p.url);currentRoomUrl=p.url;setStatus(playerMode==='iframe'?'Loaded (site controls may not sync)':'Player ready')}catch(e){setStatus(e.message)}}
async function sendPlay(){const ok=playerPlay();if(ok!==false)await broadcast('command',{action:'play',time:playerGetTime()})}
async function sendPause(){const ok=playerPause();if(ok!==false)await broadcast('command',{action:'pause',time:playerGetTime()})}
async function sendSeekPrompt(){const t=prompt('Seek to how many seconds?');if(t===null)return;const n=Number(t);if(!Number.isFinite(n))return;playerSeek(n);await broadcast('command',{action:'seek',time:n})}
async function sendSync(){if(isHost)sendCurrentState();else await broadcast('request-state',{})}
async function sendCurrentState(){const s=playerGetState();await broadcast('command',{action:'state',time:s.time,playing:s.playing})}
function handleCommand(p){if(!p)return;const t=Number(p.time)||0;if(p.action==='play'){playerSeek(t);playerPlay()}else if(p.action==='pause'){playerSeek(t);playerPause()}else if(p.action==='seek'){playerSeek(t)}else if(p.action==='state'){playerSeek(t);p.playing?playerPlay():playerPause()}$('sharedTime').textContent=formatTime(t)}
function formatTime(s){s=Math.max(0,Math.floor(Number(s)||0));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
function copyRoomLink(){navigator.clipboard?.writeText(location.href+'?room='+roomCode);alert('Room link copied!')}
function leaveRoom(){if(channel)channel.unsubscribe();location.href=location.pathname}
function browserBack(){history.back()}
function browserForward(){history.forward()}
function browserReload(){if(currentRoomUrl)setupPlayer(currentRoomUrl);else location.reload()}
window.addEventListener('load',()=>{const p=new URLSearchParams(location.search).get('room');if(p)$('roomInput').value=p.toUpperCase()});
setInterval(()=>{if(playerMode!=='none')$('sharedTime').textContent=formatTime(playerGetTime())},1000);
