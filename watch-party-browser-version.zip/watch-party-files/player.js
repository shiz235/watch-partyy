let playerMode='none';
let currentUrl='';
const video=()=>document.getElementById('videoPlayer');
const frame=()=>document.getElementById('sitePlayer');
const empty=()=>document.getElementById('emptyPlayer');
const manual=()=>document.getElementById('manualPlayer');

function detectMode(url){
  try{
    const u=new URL(url);
    const path=u.pathname.toLowerCase();
    if(/\.(mp4|webm|ogg|m4v)(\?|$)/.test(path)) return 'html5';
    if(u.hostname.includes('youtube.com')||u.hostname.includes('youtu.be')) return 'youtube';
    return 'iframe';
  }catch{return 'invalid'}
}
function youtubeId(url){
  try{const u=new URL(url); if(u.hostname.includes('youtu.be')) return u.pathname.slice(1); if(u.searchParams.get('v')) return u.searchParams.get('v'); const m=u.pathname.match(/\/embed\/([^/]+)/); return m?m[1]:null;}catch{return null}}
function showOnly(id){[video(),frame(),empty(),manual()].forEach(x=>x.classList.add('hidden'));document.getElementById(id).classList.remove('hidden')}
function setupPlayer(url){currentUrl=url;playerMode=detectMode(url);if(playerMode==='invalid'){throw new Error('Invalid URL');}
  if(playerMode==='html5'){showOnly('videoPlayer');video().src=url;video().load();return {mode:playerMode,controls:true};}
  if(playerMode==='youtube'){const id=youtubeId(url);if(!id)throw new Error('Could not read YouTube video ID');showOnly('sitePlayer');frame().src='https://www.youtube.com/embed/'+encodeURIComponent(id)+'?enablejsapi=1&playsinline=1';return {mode:playerMode,controls:false};}
  showOnly('sitePlayer');frame().src=url;return {mode:playerMode,controls:false};
}
function playerPlay(){if(playerMode==='html5') return video().play(); if(playerMode==='youtube') return postYT('playVideo'); return false}
function playerPause(){if(playerMode==='html5'){video().pause();return true}if(playerMode==='youtube')return postYT('pauseVideo');return false}
function playerSeek(t){if(playerMode==='html5'){video().currentTime=Math.max(0,Number(t)||0);return true}if(playerMode==='youtube'){postYT('seekTo',[Number(t)||0,true]);return true}return false}
function playerGetTime(){if(playerMode==='html5')return video().currentTime||0;return 0}
function playerGetState(){if(playerMode==='html5')return {time:video().currentTime||0,playing:!video().paused};return {time:0,playing:false}}
function postYT(func,args=[]){if(frame().contentWindow)frame().contentWindow.postMessage(JSON.stringify({event:'command',func,args}), 'https://www.youtube.com');return true}
