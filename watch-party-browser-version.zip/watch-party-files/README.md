# Watch Party

GitHub Pages + Supabase Realtime watch-party shell.

## What it does
- Create/join rooms.
- Paste an episode URL into a browser-like address bar.
- Share the selected URL with everyone in the room.
- Supports direct HTML5 video URLs and YouTube embeds.
- Tries to display other URLs in an iframe when the site permits embedding.
- Sends Play/Pause/Seek/Sync commands through Supabase Realtime.

## Important limitation
A GitHub Pages website cannot become Chrome and cannot override a third-party site's X-Frame-Options/CSP or cross-origin security. A generic iframe also does not expose that site's internal player controls. Therefore synchronization is fully controllable for supported player adapters (such as HTML5 video), while arbitrary embedded sites may display but not respond to Play/Pause/Seek.

## Setup
1. Put these files in the root of your GitHub repository.
2. Open `watch-party.js`.
3. Replace `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE` and `PASTE_YOUR_PUBLISHABLE_KEY_HERE`.
4. Never put a Supabase secret/service-role key in this file.
